Read Me
This is the complete package of AutoCite which is hosted on AWS with Lambda, Cloudfront, RDS and API gateway.

# Main Lambda Function
lambda_citation contains the files required to build the main lambda function that creates citations. The main code is in lambda_function.py, to compile the code, go into the lambda_citation folder and run
> zip -r lambda_function.zip .
which zips all files in the directory into lambda_function.zip and to be deployed on AWS lambda

# Cacheing Mechanism
cache_read and cache_update contain code for reading and updating a MySQL database hosted on AWS RDS. Go to "cache_env/lib/python3.7/site-packages" to edit the cache_checker.py and cache_update.py and build with 
> zip -r cache_checker.zip .
and 
> zip -r cache_update.zip .
respectively.


To enable the cache to work, start a MySQL server with the following details
	Schema: "autocite_cache"
	Table: "Records"
	Column1: "hash" [PK]
	Column2: "citation"
	User: "admin"
	Password: [set your own and modify in the cache_checker.py and cache_update.py files]
	End-point: [Ensure you set the endpoint in cache_checker.py and cache_update.py to match that of your server]

# API Configuration
After each ambda function is created, ensure to add an API Gateway trigger. 
Delete the ANY method for each trigger and replace it with a POST method
Remember to enable CORS support.


# Front-End
The font-end code is in the "autocite_lambda" directory, the only modification one needs to make to run on your own AWS account is to change the endpoint of the Lambda API for each of the 3 lambda functions (main citation function, cache checker, cache update)

# Deploying Front-End
You can use AWS S3 as a webserver for our static site. Create a bucket with a globally unique name and ensure that public access is allowed. In "Properties" tab, configure the bucket to be used for static site hosting and set the index document to "autocite_rds_cache.html". Note the web_server endpoint.

To further improve latency, deploy this to cloudfront. Create a ditribution with the web_server endpoint as the origin.
One can use Route 53 to give a CNAME to the cloud front distribution, however registering for a domain is rather pricey.

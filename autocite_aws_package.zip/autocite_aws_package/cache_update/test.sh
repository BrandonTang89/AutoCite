curl -X POST -d @data.json -H "Content-Type: application/json" https://19d0woymw1.execute-api.us-east-1.amazonaws.com/default/autocite_cache_update
